from sgml2dict.sgml2dict import convert
